var fs = require('fs');


// QS 3.1
fs.appendFile('ukinode.txt', 'It is a full scholarship  for Coding in Jaffna. It is aimed to provide the necessary training to enter Computer Software industry or to start an IT startup.', function(err) {
    if (err) throw err;
    console.log('saved file!');
});


// QS 3.2
var http = require('http');

http.createServer(function (req, res) {
    fs.readFile('ukinode.txt', function(err, data) {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(data);
        res.end();
    });
}).listen(4000);



// QS 3.3
fs.appendFile('ukinode.txt', 'This is a joint initiative by Yarl IT Hub and SERVE Foundation. Yarl IT Hub has been  on technology entrepreneurship in Sri Lanka  four year old foundation focusing on using technology in rural schools in northern Sri Lanka.', function(err) {
    if (err) throw err;
    console.log('Added text!');
});


// QS 3.4
fs.rename('ukinode.txt', 'ukinodejsexercise1.txt', function (err) {
    if (err) throw err;
    console.log('file Renamed!');
});


// QS 3.5
fs.unlink('ukinodejsexercise1.txt', function (err) {
    if (err) throw err;
    console.log('file Deleted!');
});
